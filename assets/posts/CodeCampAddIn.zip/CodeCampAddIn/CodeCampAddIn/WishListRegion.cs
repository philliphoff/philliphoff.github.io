﻿#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using OutlookTools = Microsoft.Office.Tools.Outlook;
using Office = Microsoft.Office.Core;
using System.Collections.ObjectModel;
using CodeCampAddIn.AWSECommerceService;
#endregion

namespace CodeCampAddIn
{
    [Microsoft.Office.Tools.Outlook.FormRegionMessageClassAttribute(Microsoft.Office.Tools.Outlook.FormRegionMessageClassAttribute.Contact)]
    [Microsoft.Office.Tools.Outlook.FormRegionNameAttribute("CodeCampAddIn.WishListRegion")]
    partial class WishListRegion : OutlookTools.FormRegionControl
    {
        public WishListRegion()
        {
            InitializeComponent();

            #region VSTO Designer generated code

            this.FormRegionInitializing += new EventHandler<OutlookTools.FormRegionInitializingEventArgs>(WishListRegion.WishListRegion_FormRegionInitializing);

            #endregion

            wishListControl1.button1.Click += new System.Windows.RoutedEventHandler(button1_Click);
            wishListControl1.listBox1.MouseDoubleClick += new System.Windows.Input.MouseButtonEventHandler(listBox1_MouseDoubleClick);
        }

        void listBox1_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            WishListItem item = (WishListItem)((System.Windows.Controls.ListBox)sender).SelectedItem;
            System.Diagnostics.Process.Start(item.Details.ToString());
        }

        void button1_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            wishListControl1.DataContext = GetWishList(((Outlook.ContactItem)OutlookItem).Email1Address);
        }

        private static void WishListRegion_FormRegionInitializing(object sender, OutlookTools.FormRegionInitializingEventArgs e)
        {

        }

        private void WishListRegion_FormRegionShowing(object sender, EventArgs e)
        {

        }

        private void WishListRegion_FormRegionClosed(object sender, EventArgs e)
        {

        }

        private Collection<WishListItem> GetWishList(string emailAddress)
        {
            AWSECommerceServicePortTypeClient service = new AWSECommerceServicePortTypeClient();

            service.Open();

            //
            // Search for a wish list associated with the specified email address.
            //

            ListSearch search = new ListSearch();

#warning You must obtain a (free) access key to make Amazon.com service requests.
            search.AWSAccessKeyId = "";

            ListSearchRequest request = new ListSearchRequest();

            request.ListType = ListSearchRequestListType.WishList;
            request.Email = emailAddress;

            search.Request = new ListSearchRequest[] { request };

            ListSearchResponse response = service.ListSearch(search);

            string listId = null;
            int pages = 0;

            if (response.Lists.Length > 0)
            {
                if (response.Lists[0].List.Length > 0)
                {
                    if (response.Lists[0].List[0].ListType == ListListType.WishList)
                    {
                        listId = response.Lists[0].List[0].ListId;
                        pages = Convert.ToInt32(response.Lists[0].List[0].TotalPages);
                    }
                }
            }

            if (pages > 2)
            {
                //
                // Amazon only allows a max. of two requests per lookup.
                //

                pages = 2;
            }

            var items = new Collection<WishListItem>();

            if (listId != null)
            {
                ListLookup listLookup = new ListLookup();

#warning You must obtain a (free) access key to make Amazon.com service requests.
                listLookup.AWSAccessKeyId = "";
                listLookup.Request = new ListLookupRequest[pages];

                for (int i = 0; i < pages; i++)
                {
                    listLookup.Request[i] = new ListLookupRequest();
                    listLookup.Request[i].ListId = listId;
                    listLookup.Request[i].ListType = ListLookupRequestListType.WishList;
                    listLookup.Request[i].ListTypeSpecified = true;
                    listLookup.Request[i].ProductPage = (i + 1).ToString();
                    listLookup.Request[i].ResponseGroup = new string[] { "ListItems,Images,Small" };
                }

                ListLookupResponse listLookupResponse = service.ListLookup(listLookup);

                if (listLookupResponse.Lists != null)
                {
                    foreach (Lists lists in listLookupResponse.Lists)
                    {
                        foreach (List list in lists.List)
                        {
                            foreach (ListItem item in list.ListItem)
                            {
                                items.Add(new WishListItem
                                          {
                                              Name = item.Item.ItemAttributes.Title,
                                              Image = new Uri(item.Item.SmallImage.URL),
                                              Details = new Uri(item.Item.DetailPageURL)
                                          });
                            }
                        }
                    }
                }
            }

            service.Close();

            return items;
        }
    }
}
